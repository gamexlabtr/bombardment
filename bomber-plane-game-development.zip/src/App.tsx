import { useCallback, useEffect, useRef, useState } from "react";

const GAME_WIDTH = 960;
const GAME_HEIGHT = 640;
const GROUND_Y = 520;
const MAX_HEALTH = 100;
const TOTAL_CHAPTERS = 500;
const BEST_SCORE_KEY = "bomber-best-score";
const numberFormatter = new Intl.NumberFormat("tr-TR");
const starField = Array.from({ length: 22 }, (_, index) => ({
  x: 38 + ((index * 79) % 880),
  y: 36 + ((index * 47) % 228),
  r: 1 + (index % 3) * 0.7,
}));

const WEAPON_ORDER = ["iron", "cluster", "bunker", "missile"] as const;

type Phase = "ready" | "playing" | "paused" | "gameover" | "victory";
type TargetType = "tank" | "depot" | "battery" | "bunker";
type PickupType = "bombs" | "repair" | "shield" | "arsenal";
type WeaponType = (typeof WEAPON_ORDER)[number];
type EnvironmentKind = "desert" | "forest" | "arctic" | "volcanic" | "archipelago" | "city" | "canyon" | "aurora";

type InputState = {
  left: boolean;
  right: boolean;
  up: boolean;
  down: boolean;
  bomb: boolean;
  boost: boolean;
};

type Inventory = Record<WeaponType, number>;

type Plane = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  rotation: number;
  health: number;
  cooldown: number;
  invincible: number;
  reloadTimer: number;
};

type Projectile = {
  id: number;
  weapon: WeaponType;
  x: number;
  y: number;
  vx: number;
  vy: number;
  gravity: number;
  life: number;
  radius: number;
  blastRadius: number;
  damage: number;
  color: string;
  fragment: boolean;
  clusterCount: number;
  homing: number;
};

type Target = {
  id: number;
  type: TargetType;
  x: number;
  y: number;
  width: number;
  height: number;
  hp: number;
  maxHp: number;
  speed: number;
  shootCooldown: number;
  score: number;
  canShoot: boolean;
};

type Bullet = {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
};

type Explosion = {
  id: number;
  x: number;
  y: number;
  radius: number;
  maxRadius: number;
  damage: number;
  life: number;
  maxLife: number;
  color: string;
};

type Cloud = {
  id: number;
  x: number;
  y: number;
  width: number;
  height: number;
  speed: number;
  opacity: number;
};

type Pickup = {
  id: number;
  type: PickupType;
  x: number;
  y: number;
  size: number;
  speed: number;
  spin: number;
};

type GameState = {
  phase: Phase;
  plane: Plane;
  projectiles: Projectile[];
  targets: Target[];
  bullets: Bullet[];
  explosions: Explosion[];
  clouds: Cloud[];
  pickups: Pickup[];
  score: number;
  destroyed: number;
  elapsed: number;
  distance: number;
  level: number;
  chapter: number;
  chapterProgress: number;
  chapterGoal: number;
  selectedWeapon: WeaponType;
  inventory: Inventory;
  spawnTimer: number;
  cloudTimer: number;
  pickupTimer: number;
  nextId: number;
  bestScore: number;
};

type WeaponConfig = {
  label: string;
  shortLabel: string;
  description: string;
  cooldown: number;
  maxAmmo: number;
  accent: string;
};

type EnvironmentTheme = {
  name: string;
  kind: EnvironmentKind;
  skyTop: string;
  skyMid: string;
  skyBottom: string;
  celestial: string;
  glow: string;
  groundTop: string;
  groundBottom: string;
  farMountains: string;
  nearMountains: string;
  road: string;
  cloud: string;
  horizon: string;
  accent: string;
  night: boolean;
  weatherLabel: string;
};

const emptyInput: InputState = {
  left: false,
  right: false,
  up: false,
  down: false,
  bomb: false,
  boost: false,
};

const weaponConfigs: Record<WeaponType, WeaponConfig> = {
  iron: {
    label: "Demir Bomba",
    shortLabel: "DB",
    description: "Standart tekli patlayıcı. Stok zamanla yenilenir.",
    cooldown: 0.22,
    maxAmmo: 18,
    accent: "#fbbf24",
  },
  cluster: {
    label: "Misket Bomba",
    shortLabel: "MB",
    description: "Patlayınca çoklu parçaya ayrılır.",
    cooldown: 0.38,
    maxAmmo: 8,
    accent: "#38bdf8",
  },
  bunker: {
    label: "Sığınak Delici",
    shortLabel: "SD",
    description: "Ağır hedeflerde yüksek hasar verir.",
    cooldown: 0.7,
    maxAmmo: 6,
    accent: "#f97316",
  },
  missile: {
    label: "Seyir Füzesi",
    shortLabel: "SF",
    description: "Yere ve hedefe doğru yönlenen hassas mühimmat.",
    cooldown: 0.5,
    maxAmmo: 6,
    accent: "#a78bfa",
  },
};

const themes: EnvironmentTheme[] = [
  {
    name: "Kızıl Çöl Koridoru",
    kind: "desert",
    skyTop: "#431407",
    skyMid: "#b45309",
    skyBottom: "#f59e0b",
    celestial: "#fde68a",
    glow: "rgba(253, 186, 116, 0.28)",
    groundTop: "#92400e",
    groundBottom: "#451a03",
    farMountains: "rgba(120, 53, 15, 0.34)",
    nearMountains: "rgba(146, 64, 14, 0.62)",
    road: "rgba(254, 240, 138, 0.22)",
    cloud: "#fff7ed",
    horizon: "rgba(255, 237, 213, 0.18)",
    accent: "#f97316",
    night: false,
    weatherLabel: "Sıcak hava akımı",
  },
  {
    name: "Yeşil Vadi Cephesi",
    kind: "forest",
    skyTop: "#082f49",
    skyMid: "#0f766e",
    skyBottom: "#67e8f9",
    celestial: "#fef08a",
    glow: "rgba(103, 232, 249, 0.2)",
    groundTop: "#166534",
    groundBottom: "#052e16",
    farMountains: "rgba(20, 83, 45, 0.34)",
    nearMountains: "rgba(22, 101, 52, 0.62)",
    road: "rgba(167, 243, 208, 0.2)",
    cloud: "#ecfeff",
    horizon: "rgba(134, 239, 172, 0.16)",
    accent: "#22c55e",
    night: false,
    weatherLabel: "Orman sisi",
  },
  {
    name: "Buz Seddeleri",
    kind: "arctic",
    skyTop: "#0f172a",
    skyMid: "#1d4ed8",
    skyBottom: "#93c5fd",
    celestial: "#e0f2fe",
    glow: "rgba(224, 242, 254, 0.22)",
    groundTop: "#94a3b8",
    groundBottom: "#334155",
    farMountains: "rgba(148, 163, 184, 0.3)",
    nearMountains: "rgba(191, 219, 254, 0.5)",
    road: "rgba(255,255,255,0.3)",
    cloud: "#f8fafc",
    horizon: "rgba(224, 242, 254, 0.2)",
    accent: "#60a5fa",
    night: false,
    weatherLabel: "Donmuş rüzgâr",
  },
  {
    name: "Volkanik Karanlık",
    kind: "volcanic",
    skyTop: "#111827",
    skyMid: "#3f3f46",
    skyBottom: "#7c2d12",
    celestial: "#fb7185",
    glow: "rgba(249, 115, 22, 0.18)",
    groundTop: "#3f3f46",
    groundBottom: "#0a0a0a",
    farMountains: "rgba(63, 63, 70, 0.42)",
    nearMountains: "rgba(24, 24, 27, 0.68)",
    road: "rgba(249, 115, 22, 0.18)",
    cloud: "#e5e7eb",
    horizon: "rgba(249, 115, 22, 0.12)",
    accent: "#f97316",
    night: true,
    weatherLabel: "Kül bulutları",
  },
  {
    name: "Ada Zinciri",
    kind: "archipelago",
    skyTop: "#0f172a",
    skyMid: "#0369a1",
    skyBottom: "#38bdf8",
    celestial: "#fde68a",
    glow: "rgba(125, 211, 252, 0.2)",
    groundTop: "#0f766e",
    groundBottom: "#164e63",
    farMountains: "rgba(14, 116, 144, 0.32)",
    nearMountains: "rgba(8, 145, 178, 0.5)",
    road: "rgba(186, 230, 253, 0.18)",
    cloud: "#f0fdfa",
    horizon: "rgba(165, 243, 252, 0.18)",
    accent: "#06b6d4",
    night: false,
    weatherLabel: "Deniz sisi",
  },
  {
    name: "Çelik Şehir Hattı",
    kind: "city",
    skyTop: "#020617",
    skyMid: "#312e81",
    skyBottom: "#1d4ed8",
    celestial: "#f8fafc",
    glow: "rgba(96, 165, 250, 0.18)",
    groundTop: "#475569",
    groundBottom: "#0f172a",
    farMountains: "rgba(30, 41, 59, 0.3)",
    nearMountains: "rgba(51, 65, 85, 0.52)",
    road: "rgba(248, 250, 252, 0.18)",
    cloud: "#e2e8f0",
    horizon: "rgba(147, 197, 253, 0.18)",
    accent: "#60a5fa",
    night: true,
    weatherLabel: "Neon parlaması",
  },
  {
    name: "Kanyon Geçidi",
    kind: "canyon",
    skyTop: "#172554",
    skyMid: "#7c3aed",
    skyBottom: "#fb7185",
    celestial: "#fbcfe8",
    glow: "rgba(244, 114, 182, 0.18)",
    groundTop: "#7c2d12",
    groundBottom: "#431407",
    farMountains: "rgba(124, 45, 18, 0.34)",
    nearMountains: "rgba(154, 52, 18, 0.58)",
    road: "rgba(253, 224, 71, 0.18)",
    cloud: "#fdf2f8",
    horizon: "rgba(251, 113, 133, 0.16)",
    accent: "#fb7185",
    night: false,
    weatherLabel: "Sıcak yükselim",
  },
  {
    name: "Kutup Işığı Bölgesi",
    kind: "aurora",
    skyTop: "#020617",
    skyMid: "#0f766e",
    skyBottom: "#164e63",
    celestial: "#d8b4fe",
    glow: "rgba(192, 132, 252, 0.18)",
    groundTop: "#1e293b",
    groundBottom: "#020617",
    farMountains: "rgba(15, 118, 110, 0.28)",
    nearMountains: "rgba(15, 23, 42, 0.6)",
    road: "rgba(129, 140, 248, 0.18)",
    cloud: "#ecfeff",
    horizon: "rgba(45, 212, 191, 0.14)",
    accent: "#2dd4bf",
    night: true,
    weatherLabel: "Aurora akımı",
  },
];

function clamp(value: number, min: number, max: number) {
  return Math.min(max, Math.max(min, value));
}

function randomRange(min: number, max: number) {
  return min + Math.random() * (max - min);
}

function circleRectCollision(
  cx: number,
  cy: number,
  radius: number,
  rx: number,
  ry: number,
  rw: number,
  rh: number,
) {
  const closestX = clamp(cx, rx, rx + rw);
  const closestY = clamp(cy, ry, ry + rh);
  const dx = cx - closestX;
  const dy = cy - closestY;
  return dx * dx + dy * dy <= radius * radius;
}

function rectOverlap(
  ax: number,
  ay: number,
  aw: number,
  ah: number,
  bx: number,
  by: number,
  bw: number,
  bh: number,
) {
  return ax < bx + bw && ax + aw > bx && ay < by + bh && ay + ah > by;
}

function getChapterGoal(chapter: number) {
  return 6 + ((chapter - 1) % 5) + Math.min(6, Math.floor((chapter - 1) / 80));
}

function getDifficulty(chapter: number) {
  return 1 + Math.floor((chapter - 1) / 5);
}

function getTheme(chapter: number): EnvironmentTheme {
  const index = Math.floor((chapter - 1) / 7) % themes.length;
  return themes[index];
}

function createExplosion(id: number, x: number, y: number, maxRadius: number, color: string, damage: number): Explosion {
  return {
    id,
    x,
    y,
    radius: 12,
    maxRadius,
    damage,
    life: 0.56,
    maxLife: 0.56,
    color,
  };
}

function createCloud(id: number, chapter: number, x = GAME_WIDTH + randomRange(60, 180)): Cloud {
  const theme = getTheme(chapter);
  const width = randomRange(theme.kind === "city" ? 70 : 90, theme.kind === "desert" ? 160 : 210);
  return {
    id,
    x,
    y: randomRange(46, theme.kind === "volcanic" ? 180 : 260),
    width,
    height: width * randomRange(0.32, 0.48),
    speed: randomRange(10, 34),
    opacity: theme.kind === "volcanic" ? randomRange(0.1, 0.22) : randomRange(0.18, 0.4),
  };
}

function createTarget(id: number, chapter: number, forcedX?: number): Target {
  const difficulty = getDifficulty(chapter);
  const roll = Math.random() * 100;
  const x = forcedX ?? GAME_WIDTH + randomRange(80, 220);

  if (roll < 26) {
    const height = 30;
    return {
      id,
      type: "tank",
      x,
      y: GROUND_Y - height,
      width: 58,
      height,
      hp: 1 + Math.min(2, Math.floor(difficulty / 20)),
      maxHp: 1 + Math.min(2, Math.floor(difficulty / 20)),
      speed: randomRange(18, 36 + Math.min(20, difficulty)),
      shootCooldown: randomRange(1.5, 2.8),
      score: 120 + difficulty * 4,
      canShoot: difficulty >= 3,
    };
  }

  if (roll < 52) {
    const height = 42;
    return {
      id,
      type: "depot",
      x,
      y: GROUND_Y - height,
      width: 74,
      height,
      hp: 1 + Math.min(2, Math.floor(difficulty / 25)),
      maxHp: 1 + Math.min(2, Math.floor(difficulty / 25)),
      speed: randomRange(8, 22 + Math.min(12, difficulty * 0.5)),
      shootCooldown: 99,
      score: 150 + difficulty * 6,
      canShoot: false,
    };
  }

  if (roll < 82) {
    const height = 52;
    const hp = 2 + Math.min(3, Math.floor(difficulty / 12));
    return {
      id,
      type: "battery",
      x,
      y: GROUND_Y - height,
      width: 64,
      height,
      hp,
      maxHp: hp,
      speed: randomRange(6, 20),
      shootCooldown: randomRange(0.95, 1.8),
      score: 220 + difficulty * 8,
      canShoot: true,
    };
  }

  const height = 66;
  const hp = 3 + Math.min(4, Math.floor(difficulty / 10));
  return {
    id,
    type: "bunker",
    x,
    y: GROUND_Y - height,
    width: 96,
    height,
    hp,
    maxHp: hp,
    speed: randomRange(2, 12),
    shootCooldown: randomRange(0.85, 1.6),
    score: 320 + difficulty * 10,
    canShoot: true,
  };
}

function createPickup(id: number, chapter: number, x?: number, y?: number): Pickup {
  const roll = Math.random() * 100;
  const type: PickupType = roll < 34 ? "bombs" : roll < 60 ? "repair" : roll < 82 ? "shield" : "arsenal";
  return {
    id,
    type,
    x: x ?? GAME_WIDTH + randomRange(80, 180),
    y: y ?? randomRange(160, chapter % 10 === 0 ? 310 : 360),
    size: 20,
    speed: randomRange(10, 24),
    spin: randomRange(0, Math.PI * 2),
  };
}

function firstAvailableWeapon(inventory: Inventory) {
  return WEAPON_ORDER.find((weapon) => inventory[weapon] > 0) ?? "iron";
}

function cycleInventoryWeapon(current: WeaponType, inventory: Inventory, direction: 1 | -1) {
  const startIndex = WEAPON_ORDER.indexOf(current);
  for (let step = 1; step <= WEAPON_ORDER.length; step += 1) {
    const index = (startIndex + direction * step + WEAPON_ORDER.length * 3) % WEAPON_ORDER.length;
    const candidate = WEAPON_ORDER[index];
    if (inventory[candidate] > 0) {
      return candidate;
    }
  }
  return current;
}

function createProjectile(id: number, weapon: WeaponType, plane: Plane, fragment = false): Projectile {
  if (weapon === "cluster") {
    return {
      id,
      weapon,
      x: plane.x + 22,
      y: plane.y + 16,
      vx: 82 + plane.vx * 0.1,
      vy: 72 + plane.vy * 0.16,
      gravity: 420,
      life: 4.8,
      radius: 9,
      blastRadius: 56,
      damage: 2,
      color: "#38bdf8",
      fragment,
      clusterCount: 5,
      homing: 0,
    };
  }

  if (weapon === "bunker") {
    return {
      id,
      weapon,
      x: plane.x + 24,
      y: plane.y + 18,
      vx: 58 + plane.vx * 0.08,
      vy: 52 + plane.vy * 0.1,
      gravity: 380,
      life: 5.2,
      radius: 12,
      blastRadius: 100,
      damage: 5,
      color: "#fb923c",
      fragment,
      clusterCount: 0,
      homing: 0,
    };
  }

  if (weapon === "missile") {
    return {
      id,
      weapon,
      x: plane.x + 18,
      y: plane.y + 14,
      vx: 170 + plane.vx * 0.18,
      vy: 34 + plane.vy * 0.08,
      gravity: 16,
      life: 4.6,
      radius: 8,
      blastRadius: 82,
      damage: 4,
      color: "#a78bfa",
      fragment,
      clusterCount: 0,
      homing: 0.82,
    };
  }

  return {
    id,
    weapon: "iron",
    x: plane.x + 22,
    y: plane.y + 18,
    vx: 72 + plane.vx * 0.08 + (fragment ? randomRange(-28, 28) : 0),
    vy: (fragment ? 34 : 90) + plane.vy * 0.2,
    gravity: fragment ? 360 : 440,
    life: fragment ? 2.4 : 4.8,
    radius: fragment ? 5 : 8,
    blastRadius: fragment ? 36 : 70,
    damage: fragment ? 1 : 2,
    color: fragment ? "#fef08a" : "#fbbf24",
    fragment,
    clusterCount: 0,
    homing: 0,
  };
}

function createInitialGame(bestScore: number, phase: Phase = "ready"): GameState {
  let nextId = 1;
  const takeId = () => nextId++;
  const chapter = 1;
  const chapterGoal = getChapterGoal(chapter);
  const clouds = Array.from({ length: 8 }, () => createCloud(takeId(), chapter, randomRange(-20, GAME_WIDTH + 60)));
  const targets = [createTarget(takeId(), chapter, 640), createTarget(takeId(), chapter, 880)];

  return {
    phase,
    plane: {
      x: 230,
      y: 220,
      vx: 0,
      vy: 0,
      rotation: 0,
      health: MAX_HEALTH,
      cooldown: 0,
      invincible: 0,
      reloadTimer: 0,
    },
    projectiles: [],
    targets,
    bullets: [],
    explosions: [],
    clouds,
    pickups: [],
    score: 0,
    destroyed: 0,
    elapsed: 0,
    distance: 0,
    level: getDifficulty(chapter),
    chapter,
    chapterProgress: 0,
    chapterGoal,
    selectedWeapon: "iron",
    inventory: {
      iron: 12,
      cluster: 4,
      bunker: 3,
      missile: 2,
    },
    spawnTimer: 1.12,
    cloudTimer: 0.9,
    pickupTimer: 9.5,
    nextId,
    bestScore,
  };
}

function advanceGame(state: GameState, dt: number, input: InputState): GameState {
  if (state.phase !== "playing") {
    return state;
  }

  let nextId = state.nextId;
  const takeId = () => nextId++;
  let chapter = state.chapter;
  let chapterProgress = state.chapterProgress;
  let chapterGoal = state.chapterGoal;
  const level = getDifficulty(chapter);
  const worldSpeed = 176 + Math.min(180, level * 7) + (input.boost ? 26 : 0);

  const plane = { ...state.plane };
  const inventory: Inventory = { ...state.inventory };
  let selectedWeapon = state.selectedWeapon;

  plane.cooldown = Math.max(0, plane.cooldown - dt);
  plane.invincible = Math.max(0, plane.invincible - dt);
  plane.reloadTimer += dt;

  if (plane.reloadTimer >= 2.7 && inventory.iron < weaponConfigs.iron.maxAmmo) {
    inventory.iron += 1;
    plane.reloadTimer = 0;
  }

  if (inventory[selectedWeapon] <= 0) {
    selectedWeapon = firstAvailableWeapon(inventory);
  }

  const horizontalInput = (input.right ? 1 : 0) - (input.left ? 1 : 0);
  const verticalInput = (input.down ? 1 : 0) - (input.up ? 1 : 0);
  const acceleration = input.boost ? 760 : 620;

  plane.vx += horizontalInput * acceleration * dt;
  plane.vy += verticalInput * acceleration * dt;
  plane.vx *= input.boost ? 0.94 : 0.9;
  plane.vy *= 0.92;
  plane.x = clamp(plane.x + plane.vx * dt, 110, GAME_WIDTH - 110);
  plane.y = clamp(plane.y + plane.vy * dt, 90, GROUND_Y - 110);
  plane.rotation = clamp(plane.vy * 0.05 + plane.vx * 0.03, -18, 18);

  let projectiles = [...state.projectiles];
  if (input.bomb && plane.cooldown <= 0 && inventory[selectedWeapon] > 0) {
    projectiles.push(createProjectile(takeId(), selectedWeapon, plane));
    inventory[selectedWeapon] -= 1;
    plane.cooldown = weaponConfigs[selectedWeapon].cooldown;
    if (inventory[selectedWeapon] <= 0) {
      selectedWeapon = firstAvailableWeapon(inventory);
    }
  }

  let cloudTimer = state.cloudTimer - dt;
  let clouds = state.clouds
    .map((cloud) => ({
      ...cloud,
      x: cloud.x - (worldSpeed * 0.18 + cloud.speed) * dt,
    }))
    .filter((cloud) => cloud.x + cloud.width > -120);

  if (cloudTimer <= 0) {
    clouds.push(createCloud(takeId(), chapter));
    cloudTimer = randomRange(0.75, 1.55);
  }

  let spawnTimer = state.spawnTimer - dt;
  let targets = state.targets
    .map((target) => ({
      ...target,
      x: target.x - (worldSpeed + target.speed) * dt,
      shootCooldown: target.shootCooldown - dt,
    }))
    .filter((target) => target.x + target.width > -160 && target.hp > 0);

  if (spawnTimer <= 0) {
    targets.push(createTarget(takeId(), chapter));
    spawnTimer = randomRange(Math.max(0.48, 1 - level * 0.012), Math.max(0.8, 1.55 - level * 0.008));
  }

  let bullets = state.bullets
    .map((bullet) => ({
      ...bullet,
      x: bullet.x + bullet.vx * dt,
      y: bullet.y + bullet.vy * dt,
    }))
    .filter((bullet) => bullet.x > -40 && bullet.x < GAME_WIDTH + 40 && bullet.y > -40 && bullet.y < GROUND_Y + 20);

  const spawnedExplosions: Explosion[] = [];

  targets = targets.map((target) => {
    if (target.canShoot && target.shootCooldown <= 0 && target.x < GAME_WIDTH - 60) {
      const originX = target.x + target.width * 0.5;
      const originY = target.y + 8;
      const dx = plane.x - originX;
      const dy = plane.y - originY;
      const length = Math.max(1, Math.hypot(dx, dy));
      const speed = 220 + Math.min(160, level * 4);
      bullets.push({
        id: takeId(),
        x: originX,
        y: originY,
        vx: (dx / length) * speed,
        vy: (dy / length) * speed,
        radius: target.type === "bunker" ? 5 : 4,
      });

      return {
        ...target,
        shootCooldown: randomRange(0.9, Math.max(1.15, 2.1 - level * 0.01)),
      };
    }

    return target;
  });

  const activeProjectiles: Projectile[] = [];

  for (const projectile of projectiles) {
    let updatedProjectile = { ...projectile, life: projectile.life - dt };

    if (updatedProjectile.weapon === "missile" && targets.length > 0) {
      let nearest = targets[0];
      let nearestDistance = Infinity;
      for (const target of targets) {
        const dx = target.x + target.width * 0.5 - updatedProjectile.x;
        const dy = target.y + target.height * 0.4 - updatedProjectile.y;
        const distance = Math.hypot(dx, dy);
        if (distance < nearestDistance) {
          nearestDistance = distance;
          nearest = target;
        }
      }

      const targetDx = nearest.x + nearest.width * 0.5 - updatedProjectile.x;
      const targetDy = nearest.y + nearest.height * 0.35 - updatedProjectile.y;
      const distance = Math.max(1, Math.hypot(targetDx, targetDy));
      updatedProjectile.vx += (targetDx / distance) * updatedProjectile.homing * 240 * dt;
      updatedProjectile.vy += (targetDy / distance) * updatedProjectile.homing * 240 * dt;
    }

    updatedProjectile = {
      ...updatedProjectile,
      x: updatedProjectile.x + updatedProjectile.vx * dt,
      y: updatedProjectile.y + updatedProjectile.vy * dt,
      vx: updatedProjectile.vx * (updatedProjectile.weapon === "missile" ? 0.998 : 0.996),
      vy: updatedProjectile.vy + updatedProjectile.gravity * dt,
    };

    let exploded = false;
    let explosionY = updatedProjectile.y;

    for (const target of targets) {
      if (circleRectCollision(updatedProjectile.x, updatedProjectile.y, updatedProjectile.radius, target.x, target.y, target.width, target.height)) {
        exploded = true;
        explosionY = updatedProjectile.y;
        break;
      }
    }

    if (!exploded && updatedProjectile.y >= GROUND_Y - 6) {
      exploded = true;
      explosionY = GROUND_Y - 6;
    }

    if (exploded) {
      spawnedExplosions.push(
        createExplosion(
          takeId(),
          updatedProjectile.x,
          explosionY,
          updatedProjectile.blastRadius,
          updatedProjectile.color,
          updatedProjectile.damage,
        ),
      );

      if (updatedProjectile.weapon === "cluster" && updatedProjectile.clusterCount > 0) {
        for (let index = 0; index < updatedProjectile.clusterCount; index += 1) {
          activeProjectiles.push({
            ...createProjectile(takeId(), "iron", plane, true),
            x: updatedProjectile.x,
            y: updatedProjectile.y - 8,
            vx: randomRange(-84, 84),
            vy: randomRange(20, 100),
          });
        }
      }
    } else if (
      updatedProjectile.life > 0 &&
      updatedProjectile.x > -80 &&
      updatedProjectile.x < GAME_WIDTH + 80 &&
      updatedProjectile.y < GAME_HEIGHT + 70
    ) {
      activeProjectiles.push(updatedProjectile);
    }
  }

  projectiles = activeProjectiles;

  for (const explosion of spawnedExplosions) {
    targets = targets.map((target) => {
      const nearestX = clamp(explosion.x, target.x, target.x + target.width);
      const nearestY = clamp(explosion.y, target.y, target.y + target.height);
      const distance = Math.hypot(explosion.x - nearestX, explosion.y - nearestY);
      if (distance <= explosion.maxRadius) {
        const ratio = 1 - distance / explosion.maxRadius;
        const damage = Math.max(1, Math.round(explosion.damage * (0.7 + ratio)));
        return {
          ...target,
          hp: target.hp - damage,
        };
      }
      return target;
    });

    bullets = bullets.filter((bullet) => Math.hypot(bullet.x - explosion.x, bullet.y - explosion.y) > explosion.maxRadius * 0.66);
  }

  const planeBox = {
    x: plane.x - 40,
    y: plane.y - 18,
    width: 80,
    height: 36,
  };

  targets = targets.map((target) => {
    if (
      plane.invincible <= 0 &&
      rectOverlap(planeBox.x, planeBox.y, planeBox.width, planeBox.height, target.x, target.y, target.width, target.height)
    ) {
      plane.health = Math.max(0, plane.health - 26);
      plane.invincible = 1.1;
      spawnedExplosions.push(createExplosion(takeId(), plane.x + 16, plane.y + 4, 46, "#fca5a5", 0));
      return { ...target, hp: 0 };
    }

    return target;
  });

  bullets = bullets.filter((bullet) => {
    if (
      plane.invincible <= 0 &&
      circleRectCollision(bullet.x, bullet.y, bullet.radius + 2, planeBox.x, planeBox.y, planeBox.width, planeBox.height)
    ) {
      plane.health = Math.max(0, plane.health - 14);
      plane.invincible = 0.95;
      spawnedExplosions.push(createExplosion(takeId(), bullet.x, bullet.y, 36, "#93c5fd", 0));
      return false;
    }
    return true;
  });

  let score = state.score;
  let destroyed = state.destroyed;
  let pickupTimer = state.pickupTimer - dt;
  let pickups = state.pickups
    .map((pickup) => ({
      ...pickup,
      x: pickup.x - (worldSpeed * 0.72 + pickup.speed) * dt,
      spin: pickup.spin + dt * 3.2,
    }))
    .filter((pickup) => pickup.x + pickup.size > -60);

  const survivors: Target[] = [];
  for (const target of targets) {
    if (target.hp <= 0) {
      score += target.score;
      destroyed += 1;
      chapterProgress += 1;
      spawnedExplosions.push(
        createExplosion(
          takeId(),
          target.x + target.width * 0.5,
          target.y + target.height * 0.45,
          target.type === "bunker" ? 96 : 62,
          "#fde047",
          0,
        ),
      );

      if (Math.random() < 0.16) {
        pickups.push(createPickup(takeId(), chapter, target.x + target.width * 0.5, target.y - 22));
      }
    } else {
      survivors.push(target);
    }
  }
  targets = survivors;

  while (chapter < TOTAL_CHAPTERS && chapterProgress >= chapterGoal) {
    chapterProgress -= chapterGoal;
    chapter += 1;
    chapterGoal = getChapterGoal(chapter);
    plane.health = Math.min(MAX_HEALTH, plane.health + 10);
    inventory.iron = Math.min(weaponConfigs.iron.maxAmmo, inventory.iron + 4);
    inventory.cluster = Math.min(weaponConfigs.cluster.maxAmmo, inventory.cluster + 1);
    if (chapter % 3 === 0) {
      inventory.bunker = Math.min(weaponConfigs.bunker.maxAmmo, inventory.bunker + 1);
    }
    if (chapter % 4 === 0) {
      inventory.missile = Math.min(weaponConfigs.missile.maxAmmo, inventory.missile + 1);
    }
    spawnedExplosions.push(createExplosion(takeId(), GAME_WIDTH * 0.55, 124, 48, "#a78bfa", 0));
  }

  if (pickupTimer <= 0) {
    pickups.push(createPickup(takeId(), chapter));
    pickupTimer = randomRange(7.8, 12.5);
  }

  pickups = pickups.filter((pickup) => {
    const dx = pickup.x - plane.x;
    const dy = pickup.y - plane.y;
    if (Math.hypot(dx, dy) <= pickup.size + 24) {
      if (pickup.type === "bombs") {
        inventory.iron = Math.min(weaponConfigs.iron.maxAmmo, inventory.iron + 5);
        inventory.cluster = Math.min(weaponConfigs.cluster.maxAmmo, inventory.cluster + 1);
      } else if (pickup.type === "repair") {
        plane.health = Math.min(MAX_HEALTH, plane.health + 24);
      } else if (pickup.type === "shield") {
        plane.invincible = Math.max(plane.invincible, 2.25);
      } else {
        inventory.bunker = Math.min(weaponConfigs.bunker.maxAmmo, inventory.bunker + 1);
        inventory.missile = Math.min(weaponConfigs.missile.maxAmmo, inventory.missile + 1);
      }

      spawnedExplosions.push(
        createExplosion(
          takeId(),
          pickup.x,
          pickup.y,
          42,
          pickup.type === "repair"
            ? "#34d399"
            : pickup.type === "bombs"
              ? "#60a5fa"
              : pickup.type === "shield"
                ? "#c084fc"
                : "#f97316",
          0,
        ),
      );
      return false;
    }
    return true;
  });

  if (inventory[selectedWeapon] <= 0) {
    selectedWeapon = firstAvailableWeapon(inventory);
  }

  const explosions = [...state.explosions, ...spawnedExplosions]
    .map((explosion) => ({
      ...explosion,
      life: explosion.life - dt,
      radius: Math.min(explosion.maxRadius, explosion.radius + explosion.maxRadius * 4 * dt),
    }))
    .filter((explosion) => explosion.life > 0);

  let phase: Phase = plane.health <= 0 ? "gameover" : "playing";
  if (chapter === TOTAL_CHAPTERS && chapterProgress >= chapterGoal) {
    chapterProgress = chapterGoal;
    phase = "victory";
    bullets = [];
    targets = [];
  }

  return {
    ...state,
    phase,
    plane,
    projectiles,
    targets,
    bullets,
    explosions,
    clouds,
    pickups,
    score,
    destroyed,
    elapsed: state.elapsed + dt,
    distance: state.distance + worldSpeed * dt * 0.036,
    level: getDifficulty(chapter),
    chapter,
    chapterProgress,
    chapterGoal,
    selectedWeapon,
    inventory,
    spawnTimer,
    cloudTimer,
    pickupTimer,
    nextId,
    bestScore: phase === "gameover" || phase === "victory" ? Math.max(state.bestScore, score) : state.bestScore,
  };
}

export default function App() {
  const [bestScore, setBestScore] = useState(0);
  const [game, setGame] = useState<GameState>(() => createInitialGame(0));
  const inputRef = useRef<InputState>({ ...emptyInput });

  const startGame = useCallback(() => {
    inputRef.current = { ...emptyInput };
    setGame(createInitialGame(bestScore, "playing"));
  }, [bestScore]);

  const resetToBriefing = useCallback(() => {
    inputRef.current = { ...emptyInput };
    setGame(createInitialGame(bestScore, "ready"));
  }, [bestScore]);

  const togglePause = useCallback(() => {
    setGame((current) => {
      if (current.phase === "playing") {
        return { ...current, phase: "paused" };
      }
      if (current.phase === "paused") {
        return { ...current, phase: "playing" };
      }
      return current;
    });
  }, []);

  const setControl = useCallback((key: keyof InputState, value: boolean) => {
    inputRef.current = {
      ...inputRef.current,
      [key]: value,
    };
  }, []);

  const selectWeapon = useCallback((weapon: WeaponType) => {
    setGame((current) => {
      if (current.inventory[weapon] <= 0) {
        return current;
      }
      return {
        ...current,
        selectedWeapon: weapon,
      };
    });
  }, []);

  const stepWeaponSelection = useCallback((direction: 1 | -1) => {
    setGame((current) => ({
      ...current,
      selectedWeapon: cycleInventoryWeapon(current.selectedWeapon, current.inventory, direction),
    }));
  }, []);

  useEffect(() => {
    try {
      const stored = Number(window.localStorage.getItem(BEST_SCORE_KEY) ?? 0);
      if (Number.isFinite(stored) && stored > 0) {
        setBestScore(stored);
        setGame((current) => ({
          ...current,
          bestScore: Math.max(current.bestScore, stored),
        }));
      }
    } catch {
      // ignore storage errors
    }
  }, []);

  useEffect(() => {
    if (game.bestScore > bestScore) {
      setBestScore(game.bestScore);
      try {
        window.localStorage.setItem(BEST_SCORE_KEY, String(game.bestScore));
      } catch {
        // ignore storage errors
      }
    }
  }, [bestScore, game.bestScore]);

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      const key = event.key.toLowerCase();
      if (
        [
          "arrowleft",
          "arrowright",
          "arrowup",
          "arrowdown",
          " ",
          "w",
          "a",
          "s",
          "d",
          "shift",
          "enter",
          "numpadenter",
          "q",
          "e",
          "1",
          "2",
          "3",
          "4",
        ].includes(key)
      ) {
        event.preventDefault();
      }

      if ((key === "p" || key === "escape") && !event.repeat) {
        togglePause();
        return;
      }

      if ((key === "enter" || key === "numpadenter") && !event.repeat) {
        if (game.phase === "ready" || game.phase === "gameover" || game.phase === "victory") {
          startGame();
          return;
        }

        if (game.phase === "playing") {
          setControl("bomb", true);
        }
      }

      if (key === "q" && !event.repeat) stepWeaponSelection(-1);
      if (key === "e" && !event.repeat) stepWeaponSelection(1);
      if (key === "1" && !event.repeat) selectWeapon("iron");
      if (key === "2" && !event.repeat) selectWeapon("cluster");
      if (key === "3" && !event.repeat) selectWeapon("bunker");
      if (key === "4" && !event.repeat) selectWeapon("missile");

      if (key === "arrowleft" || key === "a") setControl("left", true);
      if (key === "arrowright" || key === "d") setControl("right", true);
      if (key === "arrowup" || key === "w") setControl("up", true);
      if (key === "arrowdown" || key === "s") setControl("down", true);
      if (key === " ") setControl("bomb", true);
      if (key === "shift") setControl("boost", true);
    };

    const handleKeyUp = (event: KeyboardEvent) => {
      const key = event.key.toLowerCase();
      if (key === "arrowleft" || key === "a") setControl("left", false);
      if (key === "arrowright" || key === "d") setControl("right", false);
      if (key === "arrowup" || key === "w") setControl("up", false);
      if (key === "arrowdown" || key === "s") setControl("down", false);
      if (key === " " || key === "enter" || key === "numpadenter") setControl("bomb", false);
      if (key === "shift") setControl("boost", false);
    };

    const resetInput = () => {
      inputRef.current = { ...emptyInput };
    };

    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("keyup", handleKeyUp);
    window.addEventListener("blur", resetInput);

    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("keyup", handleKeyUp);
      window.removeEventListener("blur", resetInput);
    };
  }, [game.phase, selectWeapon, setControl, startGame, stepWeaponSelection, togglePause]);

  useEffect(() => {
    let frame = 0;
    let previous = performance.now();

    const tick = (now: number) => {
      const dt = Math.min((now - previous) / 1000, 0.033);
      previous = now;
      setGame((current) => advanceGame(current, dt, inputRef.current));
      frame = window.requestAnimationFrame(tick);
    };

    frame = window.requestAnimationFrame(tick);
    return () => window.cancelAnimationFrame(frame);
  }, []);

  const controlHandlers = (key: keyof InputState) => ({
    onPointerDown: () => setControl(key, true),
    onPointerUp: () => setControl(key, false),
    onPointerLeave: () => setControl(key, false),
    onPointerCancel: () => setControl(key, false),
  });

  const theme = getTheme(game.chapter);
  const healthPercent = (game.plane.health / MAX_HEALTH) * 100;
  const chapterProgressPercent = (game.chapterProgress / game.chapterGoal) * 100;
  const campaignPercent = (game.chapter / TOTAL_CHAPTERS) * 100;
  const remainingTargets = Math.max(0, game.chapterGoal - game.chapterProgress);
  const planeBlink = game.plane.invincible > 0 && Math.floor(game.elapsed * 18) % 2 === 0;
  const propellerAngle = game.elapsed * 1800;
  const farMountainOffset = (game.distance * 42) % 360;
  const nearMountainOffset = (game.distance * 88) % 300;
  const roadOffset = (game.distance * 210) % 100;
  const shimmerOffset = (game.distance * 16) % 960;
  const ammoTotal = WEAPON_ORDER.reduce((total, weapon) => total + game.inventory[weapon], 0);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <div className="mx-auto flex min-h-screen max-w-7xl flex-col gap-6 px-4 py-5 lg:px-6">
        <header className="flex flex-col gap-4 rounded-3xl border border-white/10 bg-white/5 p-5 shadow-2xl shadow-slate-950/30 backdrop-blur md:flex-row md:items-center md:justify-between">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 rounded-full border border-amber-400/30 bg-amber-400/10 px-3 py-1 text-xs font-semibold uppercase tracking-[0.24em] text-amber-200">
              500 Bölümlük Demir Kanat Kampanyası
            </div>
            <div>
              <h1 className="text-3xl font-black tracking-tight text-white md:text-4xl">Bombardıman Hattı</h1>
              <p className="max-w-3xl text-sm text-slate-300 md:text-base">
                Kampanya şimdi 500 bölümden oluşuyor. Her birkaç bölümde yeni bir cepheye geçiyor, arka plan ve savaş
                atmosferi değişiyor; ayrıca genişletilmiş silah envanteriyle taktik seçimi senin elinde.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 sm:grid-cols-5">
            <div className="rounded-2xl border border-white/10 bg-slate-900/60 px-4 py-3">
              <div className="text-xs uppercase tracking-[0.2em] text-slate-400">Skor</div>
              <div className="mt-1 text-2xl font-bold text-white">{numberFormatter.format(game.score)}</div>
            </div>
            <div className="rounded-2xl border border-white/10 bg-slate-900/60 px-4 py-3">
              <div className="text-xs uppercase tracking-[0.2em] text-slate-400">En İyi</div>
              <div className="mt-1 text-2xl font-bold text-cyan-300">{numberFormatter.format(bestScore)}</div>
            </div>
            <div className="rounded-2xl border border-white/10 bg-slate-900/60 px-4 py-3">
              <div className="text-xs uppercase tracking-[0.2em] text-slate-400">İmha</div>
              <div className="mt-1 text-2xl font-bold text-amber-300">{game.destroyed}</div>
            </div>
            <div className="rounded-2xl border border-white/10 bg-slate-900/60 px-4 py-3">
              <div className="text-xs uppercase tracking-[0.2em] text-slate-400">Bölüm</div>
              <div className="mt-1 text-2xl font-bold text-emerald-300">
                {game.chapter} / {TOTAL_CHAPTERS}
              </div>
            </div>
            <div className="rounded-2xl border border-white/10 bg-slate-900/60 px-4 py-3">
              <div className="text-xs uppercase tracking-[0.2em] text-slate-400">Tehdit</div>
              <div className="mt-1 text-2xl font-bold text-rose-300">T-{game.level}</div>
            </div>
          </div>
        </header>

        <main className="grid flex-1 gap-6 lg:grid-cols-[minmax(0,1.7fr)_380px]">
          <section className="rounded-[2rem] border border-white/10 bg-slate-900/75 p-3 shadow-2xl shadow-slate-950/40 backdrop-blur">
            <div className="relative overflow-hidden rounded-[1.5rem] border border-white/10 bg-slate-950 [touch-action:none]" style={{ aspectRatio: `${GAME_WIDTH} / ${GAME_HEIGHT}` }}>
              <svg viewBox={`0 0 ${GAME_WIDTH} ${GAME_HEIGHT}`} className="h-full w-full">
                <defs>
                  <linearGradient id="skyGradient" x1="0" x2="0" y1="0" y2="1">
                    <stop offset="0%" stopColor={theme.skyTop} />
                    <stop offset="50%" stopColor={theme.skyMid} />
                    <stop offset="100%" stopColor={theme.skyBottom} />
                  </linearGradient>
                  <linearGradient id="groundGradient" x1="0" x2="0" y1="0" y2="1">
                    <stop offset="0%" stopColor={theme.groundTop} />
                    <stop offset="100%" stopColor={theme.groundBottom} />
                  </linearGradient>
                  <linearGradient id="cockpitGlow" x1="0" x2="1" y1="0" y2="1">
                    <stop offset="0%" stopColor="#bae6fd" />
                    <stop offset="100%" stopColor="#0ea5e9" />
                  </linearGradient>
                </defs>

                <rect width={GAME_WIDTH} height={GAME_HEIGHT} fill="url(#skyGradient)" />
                <rect width={GAME_WIDTH} height={GAME_HEIGHT} fill={theme.horizon} opacity="0.9" />
                {theme.night && (
                  <>
                    {starField.map((star, index) => (
                      <circle
                        key={`star-${index}`}
                        cx={star.x}
                        cy={star.y}
                        r={star.r}
                        fill="rgba(255,255,255,0.85)"
                        opacity={0.45 + ((index + Math.floor(game.elapsed * 3)) % 4) * 0.12}
                      />
                    ))}
                  </>
                )}
                <circle cx="784" cy="118" r="76" fill={theme.glow} />
                <circle cx="784" cy="118" r="38" fill={theme.celestial} opacity="0.76" />

                {theme.kind === "aurora" && (
                  <>
                    <path d="M60 110 C 240 30, 420 180, 620 92 S 860 144, 940 88" fill="none" stroke="rgba(45,212,191,0.28)" strokeWidth="20" strokeLinecap="round" />
                    <path d="M40 150 C 220 70, 460 210, 680 122 S 860 152, 950 124" fill="none" stroke="rgba(192,132,252,0.22)" strokeWidth="14" strokeLinecap="round" />
                  </>
                )}

                {Array.from({ length: 5 }).map((_, index) => {
                  const x = index * 360 - farMountainOffset;
                  return (
                    <polygon
                      key={`far-${index}`}
                      points={`${x},${GROUND_Y} ${x + 130},${GROUND_Y - 170} ${x + 270},${GROUND_Y}`}
                      fill={theme.farMountains}
                    />
                  );
                })}

                {Array.from({ length: 6 }).map((_, index) => {
                  const x = index * 300 - nearMountainOffset;
                  return (
                    <polygon
                      key={`near-${index}`}
                      points={`${x},${GROUND_Y} ${x + 100},${GROUND_Y - 120} ${x + 220},${GROUND_Y}`}
                      fill={theme.nearMountains}
                    />
                  );
                })}

                {theme.kind === "city" &&
                  Array.from({ length: 11 }).map((_, index) => {
                    const x = index * 92 - (shimmerOffset * 0.4) % 92;
                    const height = 58 + (index % 4) * 18;
                    return (
                      <g key={`city-${index}`}>
                        <rect x={x} y={GROUND_Y - height} width="54" height={height} fill="rgba(15,23,42,0.66)" />
                        {Array.from({ length: 5 }).map((__, windowIndex) => (
                          <rect
                            key={`window-${index}-${windowIndex}`}
                            x={x + 8 + (windowIndex % 2) * 16}
                            y={GROUND_Y - height + 10 + Math.floor(windowIndex / 2) * 16}
                            width="6"
                            height="8"
                            fill="rgba(250,204,21,0.42)"
                          />
                        ))}
                      </g>
                    );
                  })}

                {theme.kind === "forest" &&
                  Array.from({ length: 18 }).map((_, index) => {
                    const x = index * 58 - (shimmerOffset * 0.65) % 58;
                    return (
                      <g key={`tree-${index}`} transform={`translate(${x} ${GROUND_Y - 4})`}>
                        <rect x="-2" y="0" width="4" height="18" fill="rgba(101,67,33,0.72)" />
                        <polygon points="0,-34 -18,6 18,6" fill="rgba(22,163,74,0.72)" />
                        <polygon points="0,-22 -14,10 14,10" fill="rgba(34,197,94,0.62)" />
                      </g>
                    );
                  })}

                {theme.kind === "desert" && (
                  <>
                    <path d="M0 470 Q 130 430, 240 470 T 480 470 T 720 470 T 960 470" fill="rgba(251,191,36,0.16)" />
                    <path d="M0 492 Q 150 452, 310 492 T 650 492 T 960 492" fill="rgba(254,215,170,0.12)" />
                  </>
                )}

                {theme.kind === "canyon" &&
                  Array.from({ length: 10 }).map((_, index) => {
                    const x = index * 120 - (shimmerOffset * 0.35) % 120;
                    return <rect key={`rock-${index}`} x={x} y={GROUND_Y - 32 - (index % 3) * 16} width="16" height="36" fill="rgba(251,113,133,0.18)" rx="6" />;
                  })}

                {theme.kind === "archipelago" && (
                  <>
                    <rect x="0" y={GROUND_Y - 20} width={GAME_WIDTH} height="28" fill="rgba(125,211,252,0.18)" />
                    {Array.from({ length: 8 }).map((_, index) => {
                      const x = index * 140 - (shimmerOffset * 0.4) % 140;
                      return <ellipse key={`island-${index}`} cx={x + 32} cy={GROUND_Y - 6} rx="30" ry="12" fill="rgba(20,83,45,0.28)" />;
                    })}
                  </>
                )}

                {theme.kind === "arctic" &&
                  Array.from({ length: 12 }).map((_, index) => {
                    const x = index * 86 - (shimmerOffset * 0.45) % 86;
                    return <polygon key={`ice-${index}`} points={`${x},${GROUND_Y} ${x + 14},${GROUND_Y - 34} ${x + 28},${GROUND_Y}`} fill="rgba(224,242,254,0.26)" />;
                  })}

                {theme.kind === "volcanic" && (
                  <>
                    <path d="M40 506 L110 500 L160 506 L220 498 L280 506 L340 500 L420 506 L500 500 L620 506 L700 498 L820 506 L900 500" fill="none" stroke="rgba(249,115,22,0.32)" strokeWidth="4" strokeLinecap="round" />
                    <circle cx="212" cy="476" r="10" fill="rgba(249,115,22,0.14)" />
                    <circle cx="706" cy="466" r="14" fill="rgba(251,146,60,0.12)" />
                  </>
                )}

                {game.clouds.map((cloud) => (
                  <g key={cloud.id} transform={`translate(${cloud.x} ${cloud.y})`} opacity={cloud.opacity}>
                    <ellipse cx={cloud.width * 0.26} cy={cloud.height * 0.7} rx={cloud.width * 0.24} ry={cloud.height * 0.36} fill={theme.cloud} />
                    <ellipse cx={cloud.width * 0.5} cy={cloud.height * 0.44} rx={cloud.width * 0.32} ry={cloud.height * 0.42} fill={theme.cloud} />
                    <ellipse cx={cloud.width * 0.76} cy={cloud.height * 0.72} rx={cloud.width * 0.26} ry={cloud.height * 0.34} fill={theme.cloud} />
                  </g>
                ))}

                <rect x="0" y={GROUND_Y} width={GAME_WIDTH} height={GAME_HEIGHT - GROUND_Y} fill="url(#groundGradient)" />
                <rect x="0" y={GROUND_Y} width={GAME_WIDTH} height="9" fill={theme.road} />

                {Array.from({ length: 12 }).map((_, index) => {
                  const x = index * 100 - roadOffset;
                  return <rect key={`road-${index}`} x={x} y={GROUND_Y + 56} width="58" height="8" rx="4" fill={theme.road} />;
                })}

                {game.targets.map((target) => (
                  <g key={target.id} transform={`translate(${target.x} ${target.y})`}>
                    {target.type === "depot" && (
                      <>
                        <rect width={target.width} height={target.height} rx="4" fill="#64748b" />
                        <polygon points={`4,16 ${target.width / 2},0 ${target.width - 4},16`} fill="#94a3b8" />
                        <rect x={target.width * 0.36} y={target.height * 0.4} width={target.width * 0.28} height={target.height * 0.6} rx="2" fill="#0f172a" />
                      </>
                    )}

                    {target.type === "tank" && (
                      <>
                        <rect x="2" y={target.height - 14} width={target.width - 4} height="14" rx="5" fill="#334155" />
                        <rect x="10" y={target.height - 24} width={target.width - 20} height="12" rx="4" fill="#475569" />
                        <circle cx={target.width * 0.54} cy={target.height - 26} r="7" fill="#64748b" />
                        <rect x={target.width * 0.54} y={target.height - 29} width="22" height="4" rx="2" fill="#94a3b8" />
                      </>
                    )}

                    {target.type === "battery" && (
                      <>
                        <rect x="4" y="16" width={target.width - 8} height={target.height - 16} rx="5" fill="#374151" />
                        <circle cx={target.width * 0.52} cy="18" r="10" fill="#64748b" />
                        <rect x={target.width * 0.52} y="13" width="28" height="6" rx="3" fill="#cbd5e1" transform={`rotate(-18 ${target.width * 0.52} 16)`} />
                        <rect x="10" y={target.height - 14} width={target.width - 20} height="8" rx="3" fill="#111827" />
                      </>
                    )}

                    {target.type === "bunker" && (
                      <>
                        <rect width={target.width} height={target.height} rx="8" fill="#475569" />
                        <rect x="12" y="12" width={target.width - 24} height={target.height - 22} rx="6" fill="#64748b" />
                        <circle cx={target.width * 0.56} cy="22" r="11" fill="#94a3b8" />
                        <rect x={target.width * 0.56} y="18" width="34" height="7" rx="3.5" fill="#e2e8f0" />
                        <rect x="10" y={target.height - 14} width={target.width - 20} height="6" rx="3" fill="#0f172a" />
                      </>
                    )}

                    <rect x="0" y="-10" width={target.width} height="5" rx="2.5" fill="rgba(15,23,42,0.65)" />
                    <rect
                      x="0"
                      y="-10"
                      width={Math.max(0, (target.hp / target.maxHp) * target.width)}
                      height="5"
                      rx="2.5"
                      fill={target.type === "bunker" ? "#fca5a5" : "#86efac"}
                    />
                  </g>
                ))}

                {game.pickups.map((pickup) => (
                  <g key={pickup.id} transform={`translate(${pickup.x} ${pickup.y}) rotate(${pickup.spin * 32})`}>
                    <rect
                      x={-pickup.size}
                      y={-pickup.size}
                      width={pickup.size * 2}
                      height={pickup.size * 2}
                      rx="7"
                      fill={
                        pickup.type === "repair"
                          ? "#34d399"
                          : pickup.type === "bombs"
                            ? "#60a5fa"
                            : pickup.type === "shield"
                              ? "#c084fc"
                              : "#f97316"
                      }
                    />
                    <rect x={-pickup.size * 0.56} y="-3" width={pickup.size * 1.12} height="6" rx="3" fill="rgba(255,255,255,0.82)" />
                    {pickup.type === "repair" && <rect x="-3" y={-pickup.size * 0.56} width="6" height={pickup.size * 1.12} rx="3" fill="rgba(255,255,255,0.82)" />}
                    {pickup.type === "bombs" && (
                      <>
                        <circle cx="0" cy="0" r="4" fill="rgba(255,255,255,0.92)" />
                        <rect x="-1.5" y={pickup.size * 0.22} width="3" height="8" rx="1.5" fill="rgba(255,255,255,0.92)" />
                      </>
                    )}
                    {pickup.type === "shield" && <path d="M0 -10 L10 -5 L8 7 L0 12 L-8 7 L-10 -5 Z" fill="rgba(255,255,255,0.88)" />}
                    {pickup.type === "arsenal" && (
                      <>
                        <rect x="-8" y="-10" width="16" height="4" rx="2" fill="rgba(255,255,255,0.92)" />
                        <rect x="-4" y="-2" width="8" height="12" rx="2" fill="rgba(255,255,255,0.92)" />
                      </>
                    )}
                  </g>
                ))}

                {game.bullets.map((bullet) => (
                  <g key={bullet.id} transform={`translate(${bullet.x} ${bullet.y})`}>
                    <circle r={bullet.radius + 4} fill="rgba(248,113,113,0.16)" />
                    <circle r={bullet.radius} fill="#fca5a5" />
                  </g>
                ))}

                {game.projectiles.map((projectile) => (
                  <g key={projectile.id} transform={`translate(${projectile.x} ${projectile.y}) rotate(${clamp(projectile.vy * 0.08, -14, 78)})`}>
                    {projectile.weapon === "missile" ? (
                      <>
                        <rect x="-4" y="-12" width="8" height="24" rx="4" fill="#ddd6fe" />
                        <polygon points="0,-18 -7,-6 7,-6" fill="#c4b5fd" />
                        <polygon points="-7,8 -12,16 -2,11" fill="#a78bfa" />
                        <polygon points="7,8 12,16 2,11" fill="#a78bfa" />
                      </>
                    ) : projectile.weapon === "bunker" ? (
                      <>
                        <rect x="-6" y="-14" width="12" height="28" rx="6" fill="#fdba74" />
                        <rect x="-3" y="13" width="6" height="9" rx="3" fill="#ea580c" />
                        <path d="M-8 12 L-2 20 L-2 12 Z" fill="#fb923c" />
                        <path d="M8 12 L2 20 L2 12 Z" fill="#fb923c" />
                      </>
                    ) : projectile.weapon === "cluster" ? (
                      <>
                        <rect x="-5" y="-12" width="10" height="24" rx="5" fill="#7dd3fc" />
                        <circle cx="0" cy="-2" r="3" fill="#e0f2fe" />
                        <rect x="-2" y="12" width="4" height="8" rx="2" fill="#0ea5e9" />
                      </>
                    ) : (
                      <>
                        <rect x="-4" y="-10" width="8" height="20" rx="4" fill={projectile.fragment ? "#fef08a" : "#fde68a"} />
                        <rect x="-2" y="10" width="4" height="8" rx="2" fill="#94a3b8" />
                        <path d="M-6 11 L-1 16 L-1 10 Z" fill="#94a3b8" />
                        <path d="M6 11 L1 16 L1 10 Z" fill="#94a3b8" />
                      </>
                    )}
                  </g>
                ))}

                {game.explosions.map((explosion) => {
                  const alpha = Math.max(0, explosion.life / explosion.maxLife);
                  return (
                    <g key={explosion.id} transform={`translate(${explosion.x} ${explosion.y})`} opacity={alpha}>
                      <circle r={explosion.radius} fill={explosion.color} opacity="0.22" />
                      <circle r={explosion.radius * 0.62} fill={explosion.color} opacity="0.38" />
                      <circle r={explosion.radius * 0.26} fill="#fff7ed" opacity="0.82" />
                    </g>
                  );
                })}

                <g transform={`translate(${game.plane.x} ${game.plane.y}) rotate(${game.plane.rotation})`} opacity={planeBlink ? 0.4 : 1}>
                  <ellipse cx="0" cy="0" rx="34" ry="10" fill="#cbd5e1" />
                  <rect x="-18" y="-6" width="46" height="12" rx="6" fill="#94a3b8" />
                  <rect x="-12" y="-18" width="58" height="8" rx="4" fill="#64748b" />
                  <rect x="-6" y="10" width="42" height="7" rx="3.5" fill="#475569" />
                  <polygon points="-34,0 -56,-12 -56,12" fill="#64748b" />
                  <polygon points="-46,0 -62,-8 -62,8" fill="#94a3b8" />
                  <rect x="-30" y="-22" width="12" height="28" rx="4" fill="#475569" />
                  <rect x="6" y="-22" width="12" height="28" rx="4" fill="#475569" />
                  <ellipse cx="18" cy="-2" rx="10" ry="7" fill="url(#cockpitGlow)" />
                  <rect x="-4" y="-3" width="12" height="6" rx="3" fill="#0f172a" opacity="0.65" />

                  <g transform={`rotate(${propellerAngle} -24 -2)`}>
                    <rect x="-25" y="-20" width="2" height="36" rx="1" fill="#f8fafc" opacity="0.75" />
                    <rect x="-42" y="-3" width="36" height="2" rx="1" fill="#f8fafc" opacity="0.35" />
                  </g>
                  <g transform={`rotate(${propellerAngle} 12 -2)`}>
                    <rect x="11" y="-20" width="2" height="36" rx="1" fill="#f8fafc" opacity="0.75" />
                    <rect x="-6" y="-3" width="36" height="2" rx="1" fill="#f8fafc" opacity="0.35" />
                  </g>

                  {game.plane.health < 45 && (
                    <>
                      <circle cx="-48" cy="-10" r="8" fill="rgba(148,163,184,0.32)" />
                      <circle cx="-62" cy="-18" r="12" fill="rgba(148,163,184,0.22)" />
                      <circle cx="-74" cy="-28" r="16" fill="rgba(148,163,184,0.14)" />
                    </>
                  )}
                </g>
              </svg>

              <div className="pointer-events-none absolute inset-x-4 top-4 flex flex-wrap gap-3">
                <div className="rounded-2xl border border-white/10 bg-slate-950/65 px-4 py-3 shadow-lg backdrop-blur">
                  <div className="text-[10px] uppercase tracking-[0.24em] text-slate-400">Durum</div>
                  <div className="mt-1 text-sm font-semibold text-white">
                    {game.phase === "ready"
                      ? "Brifing beklemede"
                      : game.phase === "paused"
                        ? "Uçuş duraklatıldı"
                        : game.phase === "gameover"
                          ? "Uçak düştü"
                          : game.phase === "victory"
                            ? "500. bölüm tamamlandı"
                            : "Sıcak temas"}
                  </div>
                </div>
                <div className="rounded-2xl border border-white/10 bg-slate-950/65 px-4 py-3 shadow-lg backdrop-blur">
                  <div className="text-[10px] uppercase tracking-[0.24em] text-slate-400">Cephe</div>
                  <div className="mt-1 text-sm font-semibold" style={{ color: theme.accent }}>
                    {theme.name}
                  </div>
                </div>
                <div className="rounded-2xl border border-white/10 bg-slate-950/65 px-4 py-3 shadow-lg backdrop-blur">
                  <div className="text-[10px] uppercase tracking-[0.24em] text-slate-400">Silah</div>
                  <div className="mt-1 text-sm font-semibold text-amber-300">{weaponConfigs[game.selectedWeapon].label}</div>
                </div>
              </div>

              <div className="pointer-events-none absolute inset-x-4 bottom-4 grid gap-3 md:grid-cols-3">
                <div className="rounded-2xl border border-white/10 bg-slate-950/70 p-4 backdrop-blur">
                  <div className="mb-2 flex items-center justify-between text-xs uppercase tracking-[0.2em] text-slate-400">
                    <span>Gövde Dayanımı</span>
                    <span>{Math.round(game.plane.health)}%</span>
                  </div>
                  <div className="h-3 overflow-hidden rounded-full bg-white/10">
                    <div
                      className={`h-full rounded-full ${healthPercent > 55 ? "bg-emerald-400" : healthPercent > 25 ? "bg-amber-400" : "bg-rose-500"}`}
                      style={{ width: `${Math.max(0, healthPercent)}%` }}
                    />
                  </div>
                </div>
                <div className="rounded-2xl border border-white/10 bg-slate-950/70 p-4 backdrop-blur">
                  <div className="mb-2 flex items-center justify-between text-xs uppercase tracking-[0.2em] text-slate-400">
                    <span>Bölüm İlerlemesi</span>
                    <span>{game.chapterProgress} / {game.chapterGoal}</span>
                  </div>
                  <div className="h-3 overflow-hidden rounded-full bg-white/10">
                    <div className="h-full rounded-full bg-cyan-400" style={{ width: `${Math.max(0, chapterProgressPercent)}%` }} />
                  </div>
                </div>
                <div className="rounded-2xl border border-white/10 bg-slate-950/70 p-4 backdrop-blur">
                  <div className="mb-2 flex items-center justify-between text-xs uppercase tracking-[0.2em] text-slate-400">
                    <span>Kampanya Yüzdesi</span>
                    <span>%{campaignPercent.toFixed(1)}</span>
                  </div>
                  <div className="h-3 overflow-hidden rounded-full bg-white/10">
                    <div className="h-full rounded-full bg-violet-400" style={{ width: `${Math.max(0, campaignPercent)}%` }} />
                  </div>
                </div>
              </div>

              {game.phase !== "playing" && (
                <div className="absolute inset-0 flex items-center justify-center bg-slate-950/72 px-6 backdrop-blur-md">
                  <div className="max-w-2xl rounded-[2rem] border border-white/10 bg-slate-900/85 p-8 text-center shadow-2xl shadow-slate-950/50">
                    <div className="mb-3 text-xs font-semibold uppercase tracking-[0.28em] text-amber-300">
                      {game.phase === "ready"
                        ? "500 Bölümlük Görev Brifingi"
                        : game.phase === "paused"
                          ? "Duraklatıldı"
                          : game.phase === "victory"
                            ? "Kampanya Tamamlandı"
                            : "Görev Sonu"}
                    </div>
                    <h2 className="text-3xl font-black text-white md:text-4xl">
                      {game.phase === "ready"
                        ? "Cephenin tamamı seni bekliyor"
                        : game.phase === "paused"
                          ? "Uçak havada beklemede"
                          : game.phase === "victory"
                            ? "500 bölüm başarıyla temizlendi"
                            : "Bombardıman görevi başarısız"}
                    </h2>
                    <p className="mt-4 text-sm leading-6 text-slate-300 md:text-base">
                      {game.phase === "ready"
                        ? "WASD veya yön tuşlarıyla manevra yap. Space ya da Enter ile seçili silahı ateşle. Q/E veya 1-4 ile silah değiştir. Her bölümde farklı cepheye geçecek, 500 bölüm boyunca arka plan ve tehdit yapısı sürekli değişecek."
                        : game.phase === "paused"
                          ? "Savaş alanı beklemede. Devam etmek için P tuşuna basabilir veya aşağıdaki düğmeyi kullanabilirsin."
                          : game.phase === "victory"
                            ? `Toplam ${numberFormatter.format(game.score)} puanla tüm kampanyayı bitirdin. ${game.destroyed} hedef imha ettin ve ${numberFormatter.format(Math.max(bestScore, game.bestScore))} en iyi skora ulaştın.`
                            : `Toplam ${numberFormatter.format(game.score)} puan topladın, ${game.destroyed} hedefi imha ettin. En iyi skorun ${numberFormatter.format(Math.max(bestScore, game.bestScore))}.`}
                    </p>

                    <div className="mt-6 grid gap-3 sm:grid-cols-2">
                      <button
                        type="button"
                        onClick={game.phase === "paused" ? togglePause : startGame}
                        className="rounded-2xl bg-amber-400 px-5 py-3 text-sm font-bold text-slate-950 transition hover:bg-amber-300"
                      >
                        {game.phase === "paused" ? "Göreve Dön" : game.phase === "ready" ? "Uçuşu Başlat" : "Kampanyayı Yeniden Başlat"}
                      </button>
                      <button
                        type="button"
                        onClick={resetToBriefing}
                        className="rounded-2xl border border-white/15 bg-white/5 px-5 py-3 text-sm font-semibold text-white transition hover:bg-white/10"
                      >
                        Brifinge Dön
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </section>

          <aside className="flex flex-col gap-4 rounded-[2rem] border border-white/10 bg-white/5 p-5 shadow-2xl shadow-slate-950/30 backdrop-blur">
            <div className="rounded-3xl border border-white/10 bg-slate-900/60 p-5">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <div className="text-xs uppercase tracking-[0.22em] text-slate-400">Görev Paneli</div>
                  <h3 className="mt-1 text-xl font-bold text-white">Bölüm İzleme</h3>
                </div>
                <div className="rounded-full border border-cyan-400/25 bg-cyan-400/10 px-3 py-1 text-xs font-semibold text-cyan-200">
                  Bölüm {game.chapter} / {TOTAL_CHAPTERS}
                </div>
              </div>

              <div className="mt-5 space-y-4">
                <div>
                  <div className="mb-2 flex items-center justify-between text-sm text-slate-300">
                    <span>Bu bölümde kalan hedef</span>
                    <span>{remainingTargets}</span>
                  </div>
                  <div className="h-2 overflow-hidden rounded-full bg-white/10">
                    <div className="h-full rounded-full bg-rose-400" style={{ width: `${chapterProgressPercent}%` }} />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div className="rounded-2xl border border-white/10 bg-slate-950/55 p-4">
                    <div className="text-xs uppercase tracking-[0.2em] text-slate-400">Cephe Tipi</div>
                    <div className="mt-2 text-lg font-bold" style={{ color: theme.accent }}>
                      {theme.name}
                    </div>
                    <p className="mt-2 text-xs leading-5 text-slate-400">{theme.weatherLabel}</p>
                  </div>
                  <div className="rounded-2xl border border-white/10 bg-slate-950/55 p-4">
                    <div className="text-xs uppercase tracking-[0.2em] text-slate-400">Toplam Mühimmat</div>
                    <div className="mt-2 text-lg font-bold text-amber-300">{ammoTotal}</div>
                    <p className="mt-2 text-xs leading-5 text-slate-400">Demir bomba otomatik yenilenir, özel silahlar ganimetle artar.</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="rounded-3xl border border-white/10 bg-slate-900/60 p-5">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs uppercase tracking-[0.22em] text-slate-400">Silah Envanteri</div>
                  <h3 className="mt-1 text-xl font-bold text-white">Taktik Seçimi</h3>
                </div>
                <div className="rounded-full border border-amber-400/25 bg-amber-400/10 px-3 py-1 text-xs font-semibold text-amber-200">
                  Aktif: {weaponConfigs[game.selectedWeapon].shortLabel}
                </div>
              </div>

              <div className="mt-4 grid gap-3">
                {WEAPON_ORDER.map((weapon) => {
                  const config = weaponConfigs[weapon];
                  const isSelected = game.selectedWeapon === weapon;
                  const ammo = game.inventory[weapon];
                  return (
                    <button
                      key={weapon}
                      type="button"
                      onClick={() => selectWeapon(weapon)}
                      className={`rounded-2xl border px-4 py-4 text-left transition ${
                        isSelected
                          ? "border-white/20 bg-white/10"
                          : ammo > 0
                            ? "border-white/10 bg-slate-950/45 hover:bg-slate-950/70"
                            : "border-white/5 bg-slate-950/25 opacity-55"
                      }`}
                    >
                      <div className="flex items-center justify-between gap-3">
                        <div>
                          <div className="text-sm font-bold text-white">{config.label}</div>
                          <div className="mt-1 text-xs leading-5 text-slate-400">{config.description}</div>
                        </div>
                        <div className="rounded-2xl px-3 py-2 text-sm font-black" style={{ color: config.accent, background: `${config.accent}1a` }}>
                          {ammo} / {config.maxAmmo}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="rounded-3xl border border-white/10 bg-slate-900/60 p-5">
              <div className="text-xs uppercase tracking-[0.22em] text-slate-400">Kontroller</div>
              <div className="mt-3 space-y-3 text-sm text-slate-300">
                <div className="flex items-center justify-between rounded-2xl border border-white/10 bg-slate-950/45 px-4 py-3">
                  <span>Manevra</span>
                  <span className="font-semibold text-white">WASD / Yön Tuşları</span>
                </div>
                <div className="flex items-center justify-between rounded-2xl border border-white/10 bg-slate-950/45 px-4 py-3">
                  <span>Ateş / Bırak</span>
                  <span className="font-semibold text-white">Space / Enter</span>
                </div>
                <div className="flex items-center justify-between rounded-2xl border border-white/10 bg-slate-950/45 px-4 py-3">
                  <span>Silah Değiştir</span>
                  <span className="font-semibold text-white">Q / E veya 1-4</span>
                </div>
                <div className="flex items-center justify-between rounded-2xl border border-white/10 bg-slate-950/45 px-4 py-3">
                  <span>Hızlan / Duraklat</span>
                  <span className="font-semibold text-white">Shift / P</span>
                </div>
              </div>
            </div>

            <div className="rounded-3xl border border-white/10 bg-slate-900/60 p-5">
              <div className="text-xs uppercase tracking-[0.22em] text-slate-400">Dokunmatik Kumanda</div>
              <div className="mt-4 grid grid-cols-3 gap-3">
                <button
                  type="button"
                  {...controlHandlers("up")}
                  className="rounded-2xl border border-white/10 bg-slate-950/65 px-4 py-4 text-lg font-bold text-white transition hover:bg-slate-800"
                >
                  ↑
                </button>
                <button
                  type="button"
                  {...controlHandlers("bomb")}
                  className="rounded-2xl bg-amber-400 px-4 py-4 text-sm font-black uppercase tracking-[0.18em] text-slate-950 transition hover:bg-amber-300"
                >
                  Ateş
                </button>
                <button
                  type="button"
                  {...controlHandlers("boost")}
                  className="rounded-2xl border border-cyan-400/35 bg-cyan-400/10 px-4 py-4 text-sm font-bold uppercase tracking-[0.18em] text-cyan-200 transition hover:bg-cyan-400/20"
                >
                  Boost
                </button>
                <button
                  type="button"
                  {...controlHandlers("left")}
                  className="rounded-2xl border border-white/10 bg-slate-950/65 px-4 py-4 text-lg font-bold text-white transition hover:bg-slate-800"
                >
                  ←
                </button>
                <button
                  type="button"
                  {...controlHandlers("down")}
                  className="rounded-2xl border border-white/10 bg-slate-950/65 px-4 py-4 text-lg font-bold text-white transition hover:bg-slate-800"
                >
                  ↓
                </button>
                <button
                  type="button"
                  {...controlHandlers("right")}
                  className="rounded-2xl border border-white/10 bg-slate-950/65 px-4 py-4 text-lg font-bold text-white transition hover:bg-slate-800"
                >
                  →
                </button>
              </div>
              <div className="mt-4 grid grid-cols-2 gap-3 text-xs">
                {WEAPON_ORDER.map((weapon, index) => (
                  <button
                    key={`touch-weapon-${weapon}`}
                    type="button"
                    onClick={() => selectWeapon(weapon)}
                    className={`rounded-2xl border px-3 py-3 font-semibold transition ${
                      game.selectedWeapon === weapon
                        ? "border-white/20 bg-white/10 text-white"
                        : "border-white/10 bg-slate-950/45 text-slate-300 hover:bg-slate-950/70"
                    }`}
                  >
                    {index + 1}. {weaponConfigs[weapon].shortLabel} ({game.inventory[weapon]})
                  </button>
                ))}
              </div>
            </div>

            <div className="mt-auto grid gap-3 sm:grid-cols-3 lg:grid-cols-1 xl:grid-cols-3">
              <button
                type="button"
                onClick={startGame}
                className="rounded-2xl bg-emerald-400 px-4 py-3 text-sm font-bold text-slate-950 transition hover:bg-emerald-300"
              >
                Yeni Görev
              </button>
              <button
                type="button"
                onClick={togglePause}
                className="rounded-2xl border border-white/15 bg-white/5 px-4 py-3 text-sm font-semibold text-white transition hover:bg-white/10"
              >
                {game.phase === "paused" ? "Devam Et" : "Duraklat"}
              </button>
              <button
                type="button"
                onClick={resetToBriefing}
                className="rounded-2xl border border-rose-400/20 bg-rose-400/10 px-4 py-3 text-sm font-semibold text-rose-100 transition hover:bg-rose-400/20"
              >
                Sıfırla
              </button>
            </div>
          </aside>
        </main>
      </div>
    </div>
  );
}
